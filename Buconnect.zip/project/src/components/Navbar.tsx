import React from 'react';
import { Link } from 'react-router-dom';
import { School, Coffee, ShoppingBag, Shirt } from 'lucide-react';

const Navbar = () => {
  return (
    <nav className="bg-blue-600 text-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center space-x-2">
            <School className="h-8 w-8" />
            <span className="text-xl font-bold">BUconnect</span>
          </Link>
          
          <div className="flex space-x-6">
            <Link to="/food" className="flex items-center space-x-1 hover:text-blue-200">
              <Coffee className="h-5 w-5" />
              <span>Food</span>
            </Link>
            <Link to="/laundry" className="flex items-center space-x-1 hover:text-blue-200">
              <Shirt className="h-5 w-5" />
              <span>Laundry</span>
            </Link>
            <Link to="/orders" className="flex items-center space-x-1 hover:text-blue-200">
              <ShoppingBag className="h-5 w-5" />
              <span>Orders</span>
            </Link>
          </div>

          <div className="flex space-x-4">
            <Link to="/login" className="hover:text-blue-200">Login</Link>
            <Link to="/signup" className="bg-white text-blue-600 px-4 py-2 rounded-lg hover:bg-blue-50">
              Sign Up
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;