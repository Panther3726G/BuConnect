import React, { useState } from 'react';
import { Shirt, Calendar } from 'lucide-react';
import toast from 'react-hot-toast';

const laundryItems = [
  { type: 'Shirt/T-shirt' },
  { type: 'Pants/Trousers' },
  { type: 'Jeans' },
  { type: 'Undergarments' },
  { type: 'Bedsheet' },
  { type: 'Towel' },
];

const Laundry = () => {
  const [items, setItems] = useState<Record<string, number>>({});
  const [pickupDate, setPickupDate] = useState('');

  const handleQuantityChange = (type: string, quantity: number) => {
    setItems((prev) => ({
      ...prev,
      [type]: Math.max(0, quantity),
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement laundry submission logic
    toast.success('Laundry request submitted successfully!');
    setItems({});
    setPickupDate('');
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-xl shadow-md p-8">
        <div className="flex items-center mb-6">
          <Shirt className="h-8 w-8 text-blue-600 mr-3" />
          <h1 className="text-3xl font-bold">Laundry Service</h1>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <h2 className="text-xl font-semibold mb-4">Select Items</h2>
            <div className="space-y-4">
              {laundryItems.map((item) => (
                <div key={item.type} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{item.type}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      type="button"
                      onClick={() => handleQuantityChange(item.type, (items[item.type] || 0) - 1)}
                      className="p-1 rounded-full bg-gray-100 hover:bg-gray-200"
                    >
                      -
                    </button>
                    <span className="w-8 text-center">{items[item.type] || 0}</span>
                    <button
                      type="button"
                      onClick={() => handleQuantityChange(item.type, (items[item.type] || 0) + 1)}
                      className="p-1 rounded-full bg-gray-100 hover:bg-gray-200"
                    >
                      +
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <div className="flex items-center">
                <Calendar className="h-5 w-5 mr-2" />
                Pickup Date
              </div>
            </label>
            <input
              type="date"
              value={pickupDate}
              onChange={(e) => setPickupDate(e.target.value)}
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required
            />
          </div>

          <button
            type="submit"
            disabled={Object.values(items).every((v) => v === 0) || !pickupDate}
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            Schedule Pickup
          </button>
        </form>
      </div>
    </div>
  );
};

export default Laundry;