import React from 'react';
import { Clock, CheckCircle } from 'lucide-react';

const orders = [
  
  {
    id: '1',
    vendor: 'Kathi Junction',
    items: [
      { name: 'Paneer Kathi Roll', quantity: 2 },
      { name: 'Chicken Kathi Roll', quantity: 1 },
    ],
    status: 'ready',
    timestamp: '2024-03-15T14:30:00Z',
    total: 240,
  },
  {
    id: '2',
    vendor: 'Maggie Hotspot',
    items: [
      { name: 'Masala Maggi', quantity: 1 },
      { name: 'Cheese Maggi', quantity: 1 },
    ],
    status: 'preparing',
    timestamp: '2024-03-15T14:45:00Z',
    total: 120,
  },
];

const Orders = () => {
  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">Your Orders</h1>

      <div className="space-y-6">
        {orders.map((order) => (
          <div key={order.id} className="bg-white rounded-xl shadow-md p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-semibold">{order.vendor}</h3>
              <div className="flex items-center">
                {order.status === 'ready' ? (
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                ) : (
                  <Clock className="h-5 w-5 text-blue-500 mr-2" />
                )}
                <span className={order.status === 'ready' ? 'text-green-500' : 'text-blue-500'}>
                  {order.status === 'ready' ? 'Ready for pickup' : 'Preparing'}
                </span>
              </div>
            </div>

            <div className="space-y-2 mb-4">
              {order.items.map((item, index) => (
                <div key={index} className="flex justify-between text-gray-600">
                  <span>{item.name} x {item.quantity}</span>
                </div>
              ))}
            </div>

            <div className="flex justify-between items-center pt-4 border-t">
              <div className="text-sm text-gray-500">
                {new Date(order.timestamp).toLocaleString()}
              </div>
              <div className="font-semibold">
                Total: ₹{order.total}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Orders;