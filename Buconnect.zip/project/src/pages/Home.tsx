import React from 'react';
import { Link } from 'react-router-dom';
import { Coffee, Shirt } from 'lucide-react';

const Home = () => {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Welcome to BUconnect
        </h1>
        <p className="text-xl text-gray-600">
          Your one-stop platform for campus services
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <Link to="/food" className="group">
          <div className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-center mb-4">
              <Coffee className="h-12 w-12 text-blue-600" />
            </div>
            <h2 className="text-2xl font-semibold text-center mb-2">Food & Beverages</h2>
            <p className="text-gray-600 text-center">
              Order from your favorite campus eateries and get notified when your food is ready
            </p>
          </div>
        </Link>

        <Link to="/laundry" className="group">
          <div className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-center mb-4">
              <Shirt className="h-12 w-12 text-blue-600" />
            </div>
            <h2 className="text-2xl font-semibold text-center mb-2">Laundry Service</h2>
            <p className="text-gray-600 text-center">
              Schedule laundry pickup and delivery right from your room
            </p>
          </div>
        </Link>
      </div>

      <div className="mt-12 bg-blue-50 rounded-xl p-8">
        <h2 className="text-2xl font-semibold mb-4">Available Food Vendors</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {['Mblock Mess', 'Kathi Junction', 'Maggie Hotspot', 'Snapeats', 'Quench', 'Southern Stories'].map((vendor) => (
            <div key={vendor} className="bg-white rounded-lg p-4 text-center shadow">
              <p className="font-medium text-gray-800">{vendor}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Home;