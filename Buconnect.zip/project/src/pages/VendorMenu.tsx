import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { ShoppingCart, Plus, Minus } from 'lucide-react';
import toast from 'react-hot-toast';

const menuItems = {
  'mblock-mess': [
    {
      id: 'mess-1',
      name: 'Daily Thali',
      price: 60,
      description: 'Rice, dal, 2 rotis, sabzi, and salad',
      image: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 'mess-2',
      name: 'Special Thali',
      price: 80,
      description: 'Rice, dal, 3 rotis, 2 sabzi, raita, and dessert',
      image: 'https://images.unsplash.com/photo-1598532163257-ae3c6b2524b6?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 'mess-3',
      name: 'Veg Pulao',
      price: 70,
      description: 'Fragrant rice with mixed vegetables',
      image: 'https://images.unsplash.com/photo-1596797038530-2c107229654b?auto=format&fit=crop&q=80&w=400',
    }
  ],
  'maggie-hotspot': [
    {
      id: 'maggie-1',
      name: 'Normal Maggie',
      price: 40,
      description: 'Classic Maggie noodles with masala',
      image: 'https://images.unsplash.com/photo-1612929633738-8fe44f7ec841?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 'maggie-2',
      name: 'Double Masala Maggie',
      price: 45,
      description: 'Extra spicy with double masala',
      image: 'https://images.unsplash.com/photo-1612929633738-8fe44f7ec841?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 'maggie-3',
      name: 'Cheese Maggie',
      price: 50,
      description: 'Topped with melted cheese',
      image: 'https://images.unsplash.com/photo-1612929633738-8fe44f7ec841?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 'maggie-4',
      name: 'Oregano Maggie',
      price: 55,
      description: 'Italian-style with oregano seasoning',
      image: 'https://images.unsplash.com/photo-1612929633738-8fe44f7ec841?auto=format&fit=crop&q=80&w=400',
    }
  ],
  'kathi-junction': [
    {
      id: 'kathi-1',
      name: 'Paneer Kathi Roll',
      price: 80,
      description: 'Grilled paneer with spices wrapped in paratha',
      image: 'https://images.unsplash.com/photo-1533040589888-544e3b84770a?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 'kathi-2',
      name: 'Chicken Kathi Roll',
      price: 90,
      description: 'Grilled chicken with spices wrapped in paratha',
      image: 'https://images.unsplash.com/photo-1533040589888-544e3b84770a?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 'kathi-3',
      name: 'Egg Kathi Roll',
      price: 70,
      description: 'Scrambled eggs with spices wrapped in paratha',
      image: 'https://images.unsplash.com/photo-1533040589888-544e3b84770a?auto=format&fit=crop&q=80&w=400',
    }
  ],
  'snapeats': [
    {
      id: 'snaps-1',
      name: 'Veg Sandwich',
      price: 50,
      description: 'Grilled sandwich with mixed vegetables',
      image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 'snaps-2',
      name: 'Cheese Sandwich',
      price: 60,
      description: 'Grilled sandwich with extra cheese',
      image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 'snaps-3',
      name: 'Samosa (2 pcs)',
      price: 30,
      description: 'Crispy pastry with spiced potato filling',
      image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&q=80&w=400',
    }
  ],
  'quench': [
    {
      id: 'quench-1',
      name: 'Ice Tea (Small)',
      price: 45,
      description: 'Refreshing lemon ice tea',
      image: 'https://images.unsplash.com/photo-1543253687-c931c8e01820?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 'quench-2',
      name: 'Ice Tea (Large)',
      price: 70,
      description: 'Large serving of refreshing lemon ice tea',
      image: 'https://images.unsplash.com/photo-1543253687-c931c8e01820?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 'quench-3',
      name: 'Cold Coffee',
      price: 60,
      description: 'Creamy cold coffee with ice cream',
      image: 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&q=80&w=400',
    }
  ],
  'southern-stories': [
    {
      id: 'south-1',
      name: 'Masala Dosa',
      price: 70,
      description: 'Crispy dosa with spiced potato filling',
      image: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 'south-2',
      name: 'Schezwan Dosa',
      price: 80,
      description: 'Fusion dosa with spicy schezwan sauce',
      image: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 'south-3',
      name: 'Mysore Masala Dosa',
      price: 85,
      description: 'Dosa with spicy red chutney and potato filling',
      image: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 'south-4',
      name: 'Idli (2 pcs)',
      price: 40,
      description: 'Steamed rice cakes with sambar and chutney',
      image: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 'south-5',
      name: 'Vada Sambar',
      price: 45,
      description: 'Crispy lentil donuts with sambar',
      image: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 'south-6',
      name: 'Pav Bhaji',
      price: 65,
      description: 'Spiced vegetable curry with butter-toasted buns',
      image: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 'south-7',
      name: 'Chole Bhature',
      price: 75,
      description: 'Spiced chickpea curry with fried bread',
      image: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&q=80&w=400',
    }
  ]
};

const VendorMenu = () => {
  const { id } = useParams();
  const [cart, setCart] = useState<Record<string, number>>({});

  const handleAddToCart = (itemId: string) => {
    setCart((prev) => ({
      ...prev,
      [itemId]: (prev[itemId] || 0) + 1,
    }));
  };

  const handleRemoveFromCart = (itemId: string) => {
    setCart((prev) => {
      const newCart = { ...prev };
      if (newCart[itemId] > 1) {
        newCart[itemId]--;
      } else {
        delete newCart[itemId];
      }
      return newCart;
    });
  };

  const handlePlaceOrder = () => {
    // TODO: Implement order placement logic
    toast.success('Order placed successfully!');
    setCart({});
  };

  const items = menuItems[id as keyof typeof menuItems] || [];
  const totalAmount = Object.entries(cart).reduce((total, [itemId, quantity]) => {
    const item = items.find((i) => i.id === itemId);
    return total + (item?.price || 0) * quantity;
  }, 0);

  return (
    <div className="max-w-6xl mx-auto">
      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <h1 className="text-3xl font-bold mb-8">Menu</h1>
          <div className="grid gap-6">
            {items.map((item) => (
              <div key={item.id} className="bg-white rounded-xl shadow-md p-4 flex">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-24 h-24 object-cover rounded-lg"
                />
                <div className="ml-4 flex-1">
                  <h3 className="text-xl font-semibold">{item.name}</h3>
                  <p className="text-gray-600">{item.description}</p>
                  <div className="mt-2 flex items-center justify-between">
                    <p className="text-lg font-semibold">₹{item.price}</p>
                    <div className="flex items-center space-x-2">
                      {cart[item.id] ? (
                        <>
                          <button
                            onClick={() => handleRemoveFromCart(item.id)}
                            className="p-1 rounded-full bg-gray-100 hover:bg-gray-200"
                          >
                            <Minus className="h-4 w-4" />
                          </button>
                          <span>{cart[item.id]}</span>
                        </>
                      ) : null}
                      <button
                        onClick={() => handleAddToCart(item.id)}
                        className="p-1 rounded-full bg-blue-100 hover:bg-blue-200"
                      >
                        <Plus className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {Object.keys(cart).length > 0 && (
          <div className="md:col-span-1">
            <div className="bg-white rounded-xl shadow-md p-6 sticky top-4">
              <div className="flex items-center mb-4">
                <ShoppingCart className="h-6 w-6 text-blue-600 mr-2" />
                <h2 className="text-xl font-semibold">Your Order</h2>
              </div>
              
              <div className="space-y-4">
                {Object.entries(cart).map(([itemId, quantity]) => {
                  const item = items.find((i) => i.id === itemId);
                  if (!item) return null;
                  return (
                    <div key={itemId} className="flex justify-between">
                      <span>{item.name} x {quantity}</span>
                      <span>₹{item.price * quantity}</span>
                    </div>
                  );
                })}
                
                <div className="border-t pt-4">
                  <div className="flex justify-between font-semibold">
                    <span>Total</span>
                    <span>₹{totalAmount}</span>
                  </div>
                </div>

                <button
                  onClick={handlePlaceOrder}
                  className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                >
                  Place Order
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default VendorMenu;