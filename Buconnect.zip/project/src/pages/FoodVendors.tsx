import React from 'react';
import { Link } from 'react-router-dom';
import { Store } from 'lucide-react';

const vendors = [
  {
    id: 'mblock-mess',
    name: 'Mblock Mess',
    description: 'Traditional mess food with daily changing menu',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=400',
  },
  {
    id: 'kathi-junction',
    name: 'Kathi Junction',
    description: 'Delicious rolls and wraps',
    image: 'https://images.unsplash.com/photo-1533040589888-544e3b84770a?auto=format&fit=crop&q=80&w=400',
  },
  {
    id: 'maggie-hotspot',
    name: 'Maggie Hotspot',
    description: 'Quick and tasty Maggi variations',
    image: 'https://images.unsplash.com/photo-1612929633738-8fe44f7ec841?auto=format&fit=crop&q=80&w=400',
  },
  {
    id: 'snapeats',
    name: 'Snapeats',
    description: 'Variety of snacks and quick bites',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=400',
  },
  {
    id: 'quench',
    name: 'Quench',
    description: 'Refreshing beverages and drinks',
    image: 'https://images.unsplash.com/photo-1543253687-c931c8e01820?auto=format&fit=crop&q=80&w=400',
  },
  {
    id: 'southern-stories',
    name: 'Southern Stories',
    description: 'Authentic South Indian cuisine',
    image: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&q=80&w=400',
  },
];

const FoodVendors = () => {
  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex items-center mb-8">
        <Store className="h-8 w-8 text-blue-600 mr-3" />
        <h1 className="text-3xl font-bold">Food Vendors</h1>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {vendors.map((vendor) => (
          <Link
            key={vendor.id}
            to={`/vendor/${vendor.id}`}
            className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow"
          >
            <img
              src={vendor.image}
              alt={vendor.name}
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <h3 className="text-xl font-semibold mb-2">{vendor.name}</h3>
              <p className="text-gray-600">{vendor.description}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default FoodVendors;