import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Login from './pages/Login';
import SignUp from './pages/SignUp';
import FoodVendors from './pages/FoodVendors';
import VendorMenu from './pages/VendorMenu';
import Laundry from './pages/Laundry';
import Orders from './pages/Orders';

function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<SignUp />} />
            <Route path="/food" element={<FoodVendors />} />
            <Route path="/vendor/:id" element={<VendorMenu />} />
            <Route path="/laundry" element={<Laundry />} />
            <Route path="/orders" element={<Orders />} />
          </Routes>
        </main>
        <Toaster position="bottom-center" />
      </div>
    </BrowserRouter>
  );
}

export default App;