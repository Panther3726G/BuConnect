export interface User {
  id: string;
  email: string;
  name: string;
  room: string;
}

export interface MenuItem {
  id: string;
  name: string;
  price: number;
  description: string;
  image: string;
}

export interface Vendor {
  id: string;
  name: string;
  description: string;
  image: string;
  items: MenuItem[];
}

export interface Order {
  id: string;
  userId: string;
  vendorId: string;
  items: { itemId: string; quantity: number }[];
  status: 'pending' | 'preparing' | 'ready' | 'completed';
  timestamp: string;
}

export interface LaundryItem {
  id: string;
  userId: string;
  items: { type: string; quantity: number }[];
  status: 'pending' | 'processing' | 'ready' | 'completed';
  dropoffDate: string;
  pickupDate: string;
}